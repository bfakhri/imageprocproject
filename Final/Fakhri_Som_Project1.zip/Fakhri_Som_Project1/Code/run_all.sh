#!/bin/sh
./SIFT_2-6.exec -teddy
./SIFT_2-6.exec -cones
./SIFT_6-2.exec -teddy
./SIFT_6-2.exec -cones
./SURF_2-6.exec -teddy
./SURF_2-6.exec -cones
./SURF_6-2.exec -teddy
./SURF_6-2.exec -cones
